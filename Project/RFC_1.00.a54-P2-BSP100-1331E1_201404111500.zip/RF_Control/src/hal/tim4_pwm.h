

extern uint16_t TIM4_CH1_DUTY;
extern uint16_t TIM4_CH2_DUTY;
extern uint16_t TIM4_CH3_DUTY;
extern uint16_t TIM4_CH4_DUTY; /*Il valore di questo registro deve valere da 0 - 1000 1000 corrisponde al 100%*/

extern void TIM4_PWM_Init(void);
extern void TIM4_PWM_Clk(void);

