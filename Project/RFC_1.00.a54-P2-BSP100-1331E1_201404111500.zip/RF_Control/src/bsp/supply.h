#define SUPPLY_PWMVALUE	 (TIM4_CH1_DUTY)			

extern void SUPPLY_SetValue(uint16_t voltage); 
extern uint16_t SUPPLY_GetValue(void); 

extern void SUPPLY_ON(void); 
extern void SUPPLY_OFF(void); 
extern void SUPPLY_FANON(void); 
extern void SUPPLY_FANOFF(void); 

extern void SUPPLY_Init(void);
extern void SUPPLY_Clk(void);
