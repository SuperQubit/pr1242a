#include "hal.h"
#include "bsp.h"
#include <stdio.h>
#include <stdlib.h>
#include "logic.h"
#include "parser.h"
#include "htp_msgbox.h"

extern volatile tHTPMailBox HTPMsg;
char Buffer[64];
uint8_t Modul = 0;

void Parser(char *sP)
{
	if (sP[0] == '$')
		{switch(sP[1])
		  {		
		    case 'm':
					TTY_cputs("OK\r");
        break;
        
				case 'v':
					printf("RFC1,FW:" SYS_VersionString SYS_ReleaseString "-P" HTP_VersionString ",BSP:" BSP_VersionString "-HW" HWB_VersionString "\r");
					break;
				case 'l':
				{	int par;
					if(sscanf(sP,"$l %d", &par)==1)
					{
						logger_SetDepth(par);
						TTY_cputs("OK\r");
					}
					else
						TTY_cputs("ERR\r");
				}	
					break;
				
				case 'r':
				{	int par;
					if(sscanf(sP,"$r %d", &par)==1)
					{
						if(par==0) while(1);
						else
							TTY_cputs("OK\r");
					}
					else
						TTY_cputs("ERR\r");
				}	
					break;
				
				
				case 'd':
					sscanf(sP,"$d %08x", (int *)&HTPMsg.InMessage.PercPower);
					SPI2RX_PERCPOWER=HTPMsg.InMessage.PercPower;
					SPI2RX_FREQUENZA=HTPMsg.InMessage.Frequenza  ;	
					SPI2RX_MANIPOLO=HTPMsg.InMessage.Manipolo   ;
					SPI2RX_MODULATOR=HTPMsg.InMessage.Modulazione;
					/*	
					SPI2RX_VAR_POWER=HTPMsg.InMessage.Var_Power;
					SPI2RX_VAR_TRIGON=HTPMsg.InMessage.Var_TriggerON  ;
					SPI2RX_VAR_TRIGOFF=HTPMsg.InMessage.Var_TriggerOFF ;
					SPI2RX_VAR_STIMULUS=HTPMsg.InMessage.Var_Stimulus ;
					*/
					HTPMsg.Status |=1;
					HTP_MBOX_Clk();

				
					sprintf(Buffer, "%02x%02x%02x%02x%02x%02x%02x%02x",
						HTPMsg.OutMessage.Power_App,
						HTPMsg.OutMessage.Power_Active, 
						HTPMsg.OutMessage.Power_Reactive,
						HTPMsg.OutMessage.ModulatoreActual,
				    HTPMsg.OutMessage.PercPowerActual,
						HTPMsg.OutMessage.Frequenza,
						HTPMsg.OutMessage.Frequenza,
						HTPMsg.OutMessage.Manipolo | (HTPMsg.OutMessage.LoadStatus ?128:0)
					);
					TTY_cputs(Buffer);
					COM_tx(0x0D);
					//TTY_cputs("OK\r");
        break;
				
				default:
			   TTY_cputs("UNK\r");
        break;				
       }
		}
	else  TTY_cputs("UNK\r");	
}

void PARSER_Init(void)
{
	logger_assert("READY\r");
}
uint8_t buff[64];
void PARSER_Clk(void)
{
	int len;
	if((len=COM_rxs(buff,64))!=-1)
	{		
		//COM_txsl(buff,len);
			Parser((char *)buff);
	}
}
