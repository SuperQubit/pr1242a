
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __ADC_H
#define __ADC_H



#define ADC_INPUT_0_CLK       		RCC_APB2Periph_GPIOC  
#define ADC_INPUT_0_CLK_PORT      GPIOC
#define ADC_INPUT_0_CLK_PIN       GPIO_Pin_0  

extern void ADC_Mesure_Init(void);
extern void ADC_Mesure_Clk(void);


#endif 
