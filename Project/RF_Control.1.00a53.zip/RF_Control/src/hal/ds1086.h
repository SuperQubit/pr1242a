extern void DS1086_Init(void);
extern void DS1086_Clk(void);

