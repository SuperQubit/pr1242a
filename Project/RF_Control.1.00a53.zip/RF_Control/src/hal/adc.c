#include "stm32F10x.h"
#include "stm32f10x_adc.h"
#include "stm32f10x_gpio.h"

#include "adc.h"



